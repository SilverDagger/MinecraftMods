# Recommended Cobblemon Spawn Settings

These settings match the Cobblemon Realms Classic configuration used when balancing this datapack. The datapack does not apply mod configuration automatically; set these values manually on the server if you want the same bucket balance.

## Spawn configuration export

File: `config/cobblemon/main.json`

Keep this setting enabled so Cobblemon exports its spawn configuration:

```json
{
  "exportSpawnConfig": true
}
```

Edit the existing setting in `main.json`; do not replace the full file with this snippet.

## World bucket weights

File: `config/cobblemon/spawning/best-spawner-config.json`

Set the `worldBuckets` object to:

```json
{
  "worldBuckets": {
    "boss": 0.15,
    "common": 93.25,
    "rare": 1.5,
    "ultra-rare": 0.1,
    "uncommon": 5.0
  }
}
```

Keep the other fields in `best-spawner-config.json` unchanged. The weights total 100, and `boss` remains 1.5 times the `ultra-rare` weight. These are bucket-selection weights, not individual Pokémon spawn percentages. Alpha herds remain in the `boss` bucket; this setting reduces the global selection weight of that bucket.

Designed for Cobblemon 1.8.1 · Minecraft 1.21.1